<div class="settings-field">
    <input type='number' name='<?php echo $name;?>' value='<?php echo $value; ?>' />
</div>