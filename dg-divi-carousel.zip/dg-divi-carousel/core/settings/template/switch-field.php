<label class="switch">
  <input type="checkbox" name='<?php echo $name;?>' value='1' <?php checked($value,1);?> />
  <span class="slider round"></span>
</label>