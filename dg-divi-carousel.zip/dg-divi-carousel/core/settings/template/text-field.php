<div class="settings-field">
    <input type='text' name='<?php echo $name;?>' value='<?php echo $value; ?>' />
</div>