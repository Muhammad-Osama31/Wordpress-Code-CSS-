<div class="settings-field dg-activation">
    <input id="<?php echo $id;?>" class="license-status apikey-status <?php echo empty($value) ? "deactive" : $value ; ?>" type='text' 
        name='<?php echo $name;?>' 
        value='<?php echo empty($value) ? "deactive" : $value ; ?>' /> 
</div>