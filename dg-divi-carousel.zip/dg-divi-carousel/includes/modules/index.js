import DiviCarousel from './DiviCarousel/DiviCarousel';
import DiviCarouselItem from './DiviCarouselItem/DiviCarouselItem';

export default [
    DiviCarousel,
    DiviCarouselItem
];
